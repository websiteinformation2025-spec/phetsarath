# Phetsarath Serif v1.1

ຟອນດຽວສຳລັບຈົດໝາຍທາງການ: ພາສາລາວ = Phetsarath OT, ພາສາອັງກິດ/ຕົວເລກ = ຮູບແບບ
Times — ບໍ່ຕ້ອງປ່ຽນຟອນເວລາສະຫຼັບພາສາອີກຕໍ່ໄປ.

One font for official mixed Lao/English letters: Lao text renders as
Phetsarath OT (v4.103 outlines, correct Office line breaking), while
English, digits and punctuation render in a Times style, height-matched to
the Lao letters — switch languages without switching fonts.
(v1.1, from public feedback: Latin scaled to 89% of Times size so English
caps align with the Lao letter body instead of towering over it.)

## Styles (style-linked — Word's B and I buttons work)

- Phetsarath Serif Regular / Bold / Italic / Bold Italic

## What's inside the Latin

The Latin glyphs come from **Tinos** (The Tinos Project Authors, SIL OFL),
the metric-compatible equivalent of Times New Roman by the same design
lineage. 209 Latin/punctuation glyphs per style, v1.1 scales Latin to 89% of Times size so both scripts share the same visual height.

## Install

Windows: select all 4 TTFs → right-click → Install for all users.
macOS: open with Font Book → Install.
In Word choose font "Phetsarath Serif" and type both languages freely.

## License

SIL Open Font License 1.1 throughout:
- Lao: Phetsarath OT © 2012 Ministry of Posts and Telecommunications, Laos;
  v4 engineering 2026.
- Latin: Tinos © The Tinos Project Authors.
- Combined as Phetsarath Serif, 2026, MTS Lao.

"Times New Roman" is a trademark of Monotype; this font contains no
Monotype-owned outlines — only the metrically compatible open Tinos design.
