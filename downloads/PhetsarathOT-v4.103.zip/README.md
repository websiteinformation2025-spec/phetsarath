﻿# Phetsarath OT v4.103 — Fixed & Expanded Family

Built from the official Phetsarath OT v2.00 (July 2012) outlines.
12 fonts: Light, Regular, Medium, SemiBold, Bold, Black — each with a true 12° italic.
One set of files works on both **Windows and macOS**.

## Changelog

- **v4.103** (2026-08-18): PDF robustness — all 87 contextual variant glyphs
  (mark-position variants like `uni0ECD.blw`, used when HarfBuzz decomposes ຳ
  into ໍ + າ) now carry Private Use Area codepoints (U+E000+). PDF exporters
  and font subsetters that drop unmapped glyphs can no longer lose the ໍ ring
  of ຳ when a document is converted to PDF. Rendering and shaping unchanged.
- **v4.102**: full weight ladder aligned to Saysettha's professional
  Lao ratios (measured stem comparison): Light 101 (0.83x), Medium 151 (1.25x),
  SemiBold 175 (1.45x), Bold 201 (1.66x - matches Saysettha Bold exactly),
  Black 261 (2.16x - near Saysettha Black). Lao families need gentler ladders
  than Latin: loops fill in faster.
- **v4.101**: Bold recalibrated from user feedback in real Word use —
  first Bold reduction (281→227).
- **v4.100**: added the 14 Pali/Sanskrit/Kmhmu letters (below).
- **v4.000**: 12-style family, Office line-breaking metadata fix, mark QA.

## Pali / Sanskrit / Kmhmu letters (added in v4.1)

All 14 letters added to Unicode in 2019 (U+0E86 ຆ, U+0E89 ຉ, U+0E8C ຌ, U+0E8E ຎ,
U+0E8F ຏ, U+0E90 ຐ, U+0E91 ຑ, U+0E92 ຒ, U+0E93 ຓ, U+0E98 ຘ, U+0EA0 ຠ, U+0EA8 ຨ,
U+0EA9 ຩ, U+0EAC ຬ) are now included at every weight:

- Outlines adapted from **Noto Sans Lao Looped** (Copyright The Noto Project
  Authors, SIL OFL 1.1 — license-compatible, since Phetsarath OT is itself OFL;
  attribution is embedded in each font's copyright record). For each of the six
  weights, the Noto variable font was instantiated at the weight whose stem width
  matches Phetsarath's (calibrated per style), then scaled to Phetsarath's letter
  height — so the letters harmonize with the original design at every weight.
- The new consonants are registered in the font's contextual mark-positioning
  rules with the same behavior as standard short consonants: tones, stacked
  vowel+tone combinations, below-vowels and ຳ all position correctly over them
  (verified by shaping tests — identical variant selection to ກ — and an
  exhaustive 1,204-combination collision scan per font: zero collisions).

## Line breaking in Microsoft Office — QA verdict

Verified empirically on Microsoft 365 (Office 16) by automating Word, PowerPoint and
Excel with a long unspaced Lao paragraph and inspecting every rendered line:

- **Word**: breaks at correct Lao *word* boundaries (e.g. `…ໂດຍບໍ່ມີ | ການເວັ້ນວັກ…`),
  no vowel or tone mark ever separated from its consonant. Works **out of the box —
  no add-in required**.
- **PowerPoint**: wraps at legal syllable/word boundaries. Correct.
- **Excel** (wrapped cells): wraps at legal boundaries. Correct.

Modern Office (2016 and later) performs Lao segmentation from the characters
themselves, so no LaoScript-style add-in is needed for line breaking. The LaoScript
add-ins remain useful only for *other* features (legacy-encoding conversion,
spell-checking, sorting, keyboard input) — not for wrapping.

The font-side fixes in v4.000 still matter for the rest of the ecosystem:

- `ulUnicodeRange`: recalculated from actual coverage + **Lao (25)**, **Thai (24)**,
  General Punctuation (31) — v2.00 falsely claimed *every* range and codepage,
  which confused font pickers, fallback, and the Uniscribe-era layout in
  **older Word versions (2010/2013)** still common in government offices.
- `ulCodePageRange1`: Latin 1252 + Thai 874 (the declaration Saysettha uses).
- Zero-width space stays truly invisible at every weight (the v2 ZWSP contained a
  degenerate outline that could become visible ink when emboldened — fixed).
- ZWNJ (U+200C), ZWJ (U+200D) and dotted circle (U+25CC) added.

Recommendation for documents: tag Lao text with the **Lao** proofing language
(Review → Language) — improves hyphenation-free justification, spell-check hooks
and matches how the bundled test document is built.

**For developers generating .docx files programmatically** (python-docx, docx4j,
templating engines): Lao runs MUST carry the complex-script flag or Word lays the
text out on the Latin path — which has no Lao word-break engine — and breaks lines
at arbitrary cluster boundaries (splitting words like ອັກ|ສອນ). Word sets this
automatically when you type; generated files must set it explicitly in each run's
`w:rPr`: `<w:cs/>` plus `w:szCs` (and `w:bCs`/`w:iCs` for bold/italic), with the
font in `w:rFonts w:cs="Phetsarath OT"` and language `w:lang w:bidi="lo-LA"`.
The bundled test document is built this way.

## Mark placement — QA verdict (compared against Saysettha)

Verified with an exhaustive scan: every consonant × upper-vowel × tone combination
(812 combos per font) shaped with HarfBuzz and checked for ink collisions, plus a
visual comparison grid against Saysettha v2.201:

- **Regular**: 0 collisions — placement is pixel-identical to the official v2.00
  (the same result Saysettha achieves). Phetsarath positions marks through
  per-context variant glyphs (GSUB), and all contexts work correctly.
- **Derived weights**: emboldening initially compressed the vertical gaps in
  vowel+tone stacks (216 collisions in Bold). Fixed the way Saysettha's own
  Bold/Black do it: marks gain weight at 60% of the base rate, upper vowels and
  stacked tones lift progressively, below-vowels drop lower. Result: 0 collisions
  at every weight, with stack clearances in the same range as Saysettha Bold/Black.
- **DFLT script registration added** (GSUB/GPOS): v2.00 registered its positioning
  rules only for the `lao`/`latn` scripts; Saysettha also registers `DFLT`. Apps
  that shape with the default script would silently lose all mark positioning with
  v2.00 — the likely cause of historical "marks in the wrong place" reports. v4
  now matches Saysettha's `DFLT + lao + latn`.

## Family & style linking

- Regular / Italic / Bold / Bold Italic are style-linked: Word's **B** and *I*
  buttons load the real fonts instead of synthesizing.
- Extra weights use Office-friendly subfamily names (`Phetsarath OT Light`,
  `… Medium`, `… SemiBold`, `… Black`) plus typographic family names (name16/17)
  so modern apps (Adobe, DirectWrite, macOS) group all 12 under one family.
- Correct `usWeightClass` (300–900), `fsSelection`, `macStyle`, PANOSE, italic
  angle and caret slope per style. Legal PostScript names (v2.00's contained
  spaces and parentheses — could break PDF workflows). `fsType 0` (installable).
- Regular keeps the original v2.00 outlines and TrueType hinting untouched.
  Derived weights are generated from those outlines; the ladder is aligned to
  Saysettha's professional Lao ratios (Bold = 1.66× Regular stem, matching
  Saysettha Bold — recalibrated in v4.101/v4.102 from real-world Word feedback;
  the original Souliyo-matched Bold was display-weight and too heavy for text).
  Vertical metrics are identical across all 12 fonts (and to v2.00), so existing
  documents keep their line spacing.

## Windows installation

Phetsarath OT does **not** ship with Windows — existing copies were installed
manually, so remove them first to avoid two versions coexisting:

1. Settings → Personalization → Fonts → search "Phetsarath" → Uninstall old copies
   (also check per-user installs; corporate machines may need admin).
2. Select all 12 v4 `.ttf` files → right-click → **Install for all users**.
3. Restart Office apps. Verify with the bundled `PhetsarathOT-v4-test.docx`.

## macOS installation

The same TTF files are fully macOS-compatible (standard TrueType + OpenType
`lao` shaping tables; Word for Mac uses the same HarfBuzz shaping engine the
family was validated against, and CoreText apps like Pages/Safari read the same
tables plus the typographic family grouping).

1. **Remove Souliyo's v3 Mac fonts first** (Font Book → search "Phetsarath" →
   delete) — they share the family name and have conflicting internal metadata
   (the v3 Bold reports itself as weight 400 with a duplicate PostScript name).
2. Install the 12 v4 TTFs via Font Book (they carry version 4.103 and
   proper Mac name records).
3. Quick smoke test: open the interactive specimen page in Safari — it renders
   through CoreText/WebKit, so correct display there confirms Mac compatibility.

## Web

`woff2/` contains WOFF2 builds of all 12 fonts for government websites
(`font-family: 'Phetsarath OT'` with `font-weight: 300–900`).

## Known limitations

- Tops of tall tone-mark stacks exceed `usWinAscent` at heavy weights (the v2.00
  design already did this by 49 units). Harmless in Office/DirectWrite; only very
  old GDI apps might clip the topmost pixel row of extreme stacks at Black weight.
- The Pali letters do not participate in kerning pairs (spacing is metric-correct
  but without optical pair adjustments — rarely noticeable in Pali text).
- On Office 2010/2013 the Uniscribe engine may still need text tagged as Lao
  language for best segmentation — the v4 declarations match the Saysettha fonts
  that behave best on those versions.



